export interface Message {
    type: string;
    data: any;
    sdp: any;
    candidate: any;
    id: any;
    label: any;
}


